import os
import cv2
import numpy as np
import tkinter as tk
from tkinter import scrolledtext
from tkinter import messagebox

# Initialize the neural network
net = cv2.dnn.readNetFromCaffe('models/deploy.prototxt', 'models/mobilenet_iter_73000.caffemodel')

# Variables for counts
left_to_right_count = 0
right_to_left_count = 0
person_ids = {}
next_id = 1
confidence_threshold = 0.5
buffer_distance = 20
counts_file = 'counts.txt'

# Read counts from file if exists
if os.path.exists(counts_file):
    try:
        with open(counts_file, 'r') as f:
            lines = f.readlines()
            if len(lines) >= 2:
                left_to_right_count = int(lines[0].split(':')[-1].strip())
                right_to_left_count = int(lines[1].split(':')[-1].strip())
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")

# Function to start video capture and person detection
def start_camera():
    global left_to_right_count, right_to_left_count, next_id, person_ids
    cap = cv2.VideoCapture(0)

    frame_width = int(cap.get(3))
    frame_height = int(cap.get(4))
    line_position = frame_width // 2

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        blob = cv2.dnn.blobFromImage(frame, 0.007843, (300, 300), 127.5)
        net.setInput(blob)
        detections = net.forward()

        for i in range(detections.shape[2]):
            confidence = detections[0, 0, i, 2]

            if confidence > confidence_threshold:
                class_id = int(detections[0, 0, i, 1])

                if class_id == 15:  # Person class ID is 15
                    box = detections[0, 0, i, 3:7] * np.array([frame_width, frame_height, frame_width, frame_height])
                    (x, y, x2, y2) = box.astype("int")

                    cx = int((x + x2) / 2)
                    cy = int((y + y2) / 2)

                    cv2.rectangle(frame, (x, y), (x2, y2), (0, 255, 0), 2)

                    matched_id = None
                    for person_id, status in person_ids.items():
                        if abs(status['cx'] - cx) < buffer_distance and abs(status['cy'] - cy) < buffer_distance:
                            matched_id = person_id
                            break

                    if matched_id is None:
                        matched_id = next_id
                        person_ids[matched_id] = {'cx': cx, 'cy': cy, 'direction': None, 'crossed': False}
                        next_id += 1
                    else:
                        person_ids[matched_id]['cx'] = cx
                        person_ids[matched_id]['cy'] = cy

                    if cx > line_position and person_ids[matched_id]["direction"] == "left":
                        left_to_right_count += 1
                        person_ids[matched_id]["direction"] = "right"
                        person_ids[matched_id]["crossed"] = True
                        print(f"ID: {matched_id} Out，counts: {left_to_right_count}")

                    elif cx < line_position and person_ids[matched_id]["direction"] == "right":
                        right_to_left_count += 1
                        person_ids[matched_id]["direction"] = "left"
                        person_ids[matched_id]["crossed"] = True
                        print(f"ID: {matched_id} Enter，counts: {right_to_left_count}")

                    if cx < line_position and person_ids[matched_id]["direction"] is None:
                        person_ids[matched_id]["direction"] = "left"
                    elif cx > line_position and person_ids[matched_id]["direction"] is None:
                        person_ids[matched_id]["direction"] = "right"

                    if abs(cx - line_position) > buffer_distance:
                        person_ids[matched_id]["crossed"] = False

        cv2.line(frame, (line_position, 0), (line_position, frame_height), (0, 0, 255), 2)

        cv2.putText(frame, f'Out: {left_to_right_count}', (10, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.putText(frame, f'Enter: {right_to_left_count}', (10, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        cv2.imshow('Frame', frame)

        try:
            with open(counts_file, 'w') as f:
                f.write(f"People out counts:{left_to_right_count}\n")
                f.write(f"People enter counts:{right_to_left_count}\n")
        except Exception as e:
            print(f"An error occurred while writing the file: {e}")

        if cv2.waitKey(30) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# Function to view people count records
def view_records():
    record_window = tk.Toplevel()
    record_window.title("Traffic flow record")
    record_window.geometry("300x300")

    txt = scrolledtext.ScrolledText(record_window, width=40, height=10)
    txt.pack()

    # Load and display the current record
    if os.path.exists(counts_file):
        with open(counts_file, 'r') as f:
            records = f.read()
        txt.insert(tk.END, records)
    else:
        txt.insert(tk.END, "No record file")

    def clear_records():
        # Clear the counts in the file
        open(counts_file, 'w').close()  # This will empty the file
        txt.delete('1.0', tk.END)  # Clear the text widget
        txt.insert(tk.END, "Record cleared")
        global left_to_right_count, right_to_left_count
        left_to_right_count = 0
        right_to_left_count = 0

    # Add Clear button
    clear_btn = tk.Button(record_window, text="Clear History", width=20, height=2, command=clear_records)
    clear_btn.pack(pady=10)

# Function to close the program
def close_program():
    root.quit()

# Create GUI window
root = tk.Tk()
root.title("People Detection system")
root.geometry('500x400')

# Buttons
start_btn = tk.Button(root, text="Start the camera", width=20, height=2, command=start_camera)
start_btn.pack(pady=20)

view_btn = tk.Button(root, text="View counter records", width=20, height=2, command=view_records)
view_btn.pack(pady=20)

close_btn = tk.Button(root, text="Close", width=20, height=2, command=close_program)
close_btn.pack(pady=20)

root.mainloop()
